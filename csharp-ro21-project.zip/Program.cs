using System;

class Program
{
    static void Main()
    {
        Console.Write("Введите целое неотрицательное число: ");
        if (!int.TryParse(Console.ReadLine(), out int number) || number < 0)
        {
            Console.WriteLine("Ошибка: введите целое неотрицательное число.");
            return;
        }

        int originalNumber = number;
        int digitSum = 0;
        int digitCount = 0;

        if (number == 0)
        {
            digitCount = 1;
        }
        else
        {
            while (number > 0)
            {
                digitSum += number % 10;
                digitCount++;
                number /= 10;
            }
        }

        Console.WriteLine($"Исходное число: {originalNumber}");
        Console.WriteLine($"Количество цифр: {digitCount}");
        Console.WriteLine($"Сумма цифр: {digitSum}");
        Console.WriteLine($"Чётное ли число: {(originalNumber % 2 == 0 ? "да" : "нет")}");
    }
}
